const express = require('express');
const ejs = require('ejs')
const paypal = require('paypal-rest-sdk')
const app = express();
const port = process.env.PORT || 3000



// paypal Client ID and Client Secret
paypal.configure({
    'mode': 'sandbox', //sandbox or live
    'client_id': 'AYvh6L3NTYf0z5npFxOEXGn8ybxqWRWVRy1XOcsyL_eAaXAvKolxUO5FigHe5mmSNQ7U9A77Y7p5V18y',
    'client_secret': 'EOOyyG4riJG82ydgL4R5wfWHSgkVoXBbDwQLteI4ecy4Ijqvs1Gf4GsiqjMYJlivNRdV2Xj3mvxL6shv'
  });






app.set('view engine' ,'ejs')

app.get('/',(req,res)=>{
    res.render('index')
})

app.post('/pay',(req,res)=>{
    const create_payment_json = {
        "intent": "sale",
        "payer": {
            "payment_method": "paypal"
        },
        "redirect_urls": {
            "return_url": "http://localhost:3000/success",
            "cancel_url": "http://localhost:3000/cancel"
        },
        "transactions": [{
            "item_list": {
                "items": [{
                    "name": "red sox hat",
                    "sku": "001",
                    "price": "2000",
                    "currency": "INR",
                    "quantity": 1
                }]
            },
            "amount": {
                "currency": "INR",
                "total": "2000"
            },
            "description": "Hat for the best price team ever"
        }]
    }; 


paypal.payment.create(create_payment_json, function (error, payment) {
    if (error) {
        throw error;
    } else {
       for(let i = 0 ;i < payment.links.length;i++){
             if(payment.links[i].rel === 'approval_url'){
                 res.redirect(payment.links[i].href);
             }
       }
    }
});

});




app.get('/success', (req, res) => {
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
  
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
          "amount": {
              "currency": "INR",
              "total": "2000"
          }
      }]
    };
  
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
      if (error) {
          console.log(error.response);
          throw error;
      } else {
          console.log(JSON.stringify(payment));
          res.send('Success');
      }
  });
  });
  


app.get('/cancel', (req,res) => res.send('cancelled'))


app.listen(port,()=>console.log(`app is running at ${port}`))
